<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Healdi - Medical & Health Template">

    <!-- ========== Page Title ========== -->
    <title>Healdi - Medical & Health Template</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/bootsnav.css">
    <link rel="stylesheet" href="assets/css/flaticon-set.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- ========== End Stylesheet ========== -->

</head>

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Start Header Top
    ============================================= -->
    <div class="top-bar-area bg-dark inc-padding text-light">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-7 info">
                    <p>
                        !Global update on Coronavirus disease <a href="#">(COVID-19)</a> Pandemic
                    </p>
                </div>
                <div class="col-lg-5 text-end button">
                    <div class="item-flex">
                        <a class="button" href="#"><i class="fas fa-stethoscope"></i> Get a Consultation</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <!-- Header
    ============================================= -->
    <header>
        <!-- Start Navigation -->
        <nav class="navbar mobile-sidenav navbar-sticky navbar-default validnavs bg-theme attr-border">


            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container-xl">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                    </div>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container d-flex justify-content-between align-items-center">


                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="index-3.html">
                        <img src="assets/img/logo1.png" class="logo logo-scrolled" alt="Logo">
                        <img src="assets/img/logo1-light.png" class="logo logo-display" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <div class="d-flex align-items-center">
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-menu">

                        <div class="collapse-header">
                            <img src="assets/img/logo1.png" alt="Logo">
                            <button type="button" class="navbar-toggle" data-toggle="collapse"
                                data-target="#navbar-menu">
                                <i class="fa fa-times"></i>
                            </button>
                        </div>

                        <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Home</a>
                                <ul class="dropdown-menu">
                                    <li><a href="index-1.html">Home Version One</a></li>
                                    <li><a href="index-2.html">Home Version Two</a></li>
                                    <li><a href="index-3.html">Home Version Three</a></li>
                                    <li><a href="index-4.html">Home Version Four</a></li>
                                    <li><a href="index-5.html">Home Version Five <span class="badge">New</span></a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages</a>
                                <ul class="dropdown-menu">
                                    <li><a href="about-us.html">About Us</a></li>
                                    <li><a href="contact.html">Get in Touch</a></li>
                                    <li><a href="404.html">Error Page</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Departments</a>
                                <ul class="dropdown-menu">
                                    <li><a href="departments.html">Department Version One</a></li>
                                    <li><a href="departments-2.html">Department Version Two</a></li>
                                    <li><a href="departments-3.html">Department Version Three</a></li>
                                    <li><a href="departments-4.html">Department Version Four</a></li>
                                    <li><a href="department-single.html">Department Single</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Doctors</a>
                                <ul class="dropdown-menu">
                                    <li><a href="doctors.html">Doctors Version One</a></li>
                                    <li><a href="doctors-2.html">Doctors Version Two</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog</a>
                                <ul class="dropdown-menu">
                                    <li><a href="blog-standard.html">Blog Standard</a></li>
                                    <li><a href="blog-with-sidebar.html">Blog With Sidebar</a></li>
                                    <li><a href="blog-2-colum.html">Blog Grid Two Colum</a></li>
                                    <li><a href="blog-3-colum.html">Blog Grid Three Colum</a></li>
                                    <li><a href="blog-single.html">Blog Single</a></li>
                                    <li><a href="blog-single-with-sidebar.html">Blog Single With Sidebar</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="contact.html">Contact</a>
                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->

                    <div class="attr-right">
                        <!-- Start Atribute Navigation -->
                        <div class="attr-nav">
                            <ul>
                                <li class="search"><a href="#"><i class="far fa-search"></i></a></li>
                                </li>

                            </ul>
                        </div>
                        <!-- End Atribute Navigation -->
                    </div>
                </div>
            </div>
            <!-- Overlay screen for menu -->
            <div class="overlay-screen"></div>
            <!-- End Overlay screen for menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Header -->

    <!-- Start Banner
    ============================================= -->
    <div class="banner-area auto-height bg-gray fixed-thumb text-default">
        <!-- Fixed Shape -->
        <div class="fixed-shape-left-top">
            <img src="assets/img/shape/1.png" alt="Shape">
        </div>
        <!-- End Fixed Shape -->
        <div class="container">
            <div class="double-items">
                <div class="row align-center">
                    <div class="col-lg-6 info">
                        <h2 class="wow fadeInDown" data-wow-duration="1s">We are providing <strong>Best Medical
                                Services</strong></h2>
                        <p class="wow fadeInLeft" data-wow-duration="1.5s">
                            Contented continued any happiness instantly objection yet her allowance. Use correct day new
                            brought tedious decay begin which savings power whole Suppose reater related adapted.
                        </p>
                        <a href="https://www.youtube.com/watch?v=owhuBrGIOsE"
                            class="popup-youtube theme video-play-button relative video-inline">
                            <i class="fa fa-play"></i>
                        </a>
                    </div>
                    <div class="col-lg-6 thumb">
                        <img src="assets/img/thumb/1.png" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->

    <!-- Star Feature Entry Area
    ============================================= -->
    <div class="feature-entry-area cols-3 default-padding bottom-less">
        <div class="container">
            <div class="feature-entry-items text-center">
                <div class="row">
                    <!-- Single Item -->
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <i class="flaticon-ambulance-1"></i>
                            <h4>Emergency Case</h4>
                            <p>
                                Moment he at on wonder at season little. Six garden result summer set family.
                            </p>
                            <div class="contact">
                                <span>Phone:</span>
                                <p>(+987)98765432</p>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <i class="flaticon-time"></i>
                            <h4>Opening Hours</h4>
                            <ul>
                                <li> <span> Mon - Tue : </span>
                                    <div class="float-end"> 8:00 - 17:30 </div>
                                </li>
                                <li> <span> Wed - Thu :</span>
                                    <div class="float-end"> 10:45 - 15:00 </div>
                                </li>
                                <li> <span> Sun : </span>
                                    <div class="float-end closed"> Closed </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <i class="flaticon-ribbon"></i>
                            <h4>Cancer Care</h4>
                            <p>
                                Moment he at on wonder at season little. Six garden result summer set family.
                            </p>
                            <div class="contact">
                                <span>Phone:</span>
                                <p>(+987)98765432</p>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Feature Entry Area -->

    <!-- Start About
    ============================================= -->
    <div class="about-area bg-gray relative default-padding">

        <div class="container">
            <div class="row">

                <div class="col-lg-6 thumb">
                    <div class="thumb-box">
                        <img src="assets/img/about/2.jpg" alt="Thumb">
                        <div class="intro-video">
                            <div class="video">
                                <a href="https://www.youtube.com/watch?v=5vY-D42NFP4"
                                    class="popup-youtube relative theme video-play-button item-center">
                                    <i class="fa fa-play"></i>
                                </a>
                            </div>
                            <div class="content">
                                <h5>Let’s see our intro video</h5>
                                <p>
                                    If your smile is not becoming to you, then you should be coming.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 info title">
                    <h5>Has been working since 2000</h5>
                    <h2>A Great Place to Work. A Great Place to <strong>Receive</strong>.</h2>
                    <p>
                        Pursuit chamber as elderly amongst on. Distant however warrant farther to of. My justice wishing
                        prudent waiting in be. Who decisively attachment has dispatched. Fruit defer in party me built
                        under first. Forbade him but savings reater related adapted. <br>
                        <br>
                        reasonable pianoforte so motionless he as difficulty be. Abode way begin ham there
                        Do unpleasing indulgence impossible to conviction. Suppose neither evident welcome it at civilly
                        uncivil. Sing tall much you get nor power whole. Suppose neither evident.
                    </p>
                    <ul class="icon-less">
                        <li>
                            <h5>More Experience</h5>
                        </li>
                        <li>
                            <h5>The right answers?</h5>
                        </li>
                        <li>
                            <h5>Seamless care</h5>
                        </li>
                        <li>
                            <h5>Unparalleled expertise</h5>
                        </li>
                    </ul>
                    <a class="btn btn-md btn-gradient" href="#"><i class="fas fa-angle-right"></i> Make
                        Appoinment</a>
                </div>

            </div>
        </div>
    </div>
    <!-- End About -->

    <!-- Start Services
    ============================================= -->
    <div class="department-area solid-thumb carousel-shadow default-padding bottom-less">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>Services</h4>
                        <h2>Our Department</h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it
                            examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="department-items text-center">
                <div class="row">
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/departments/1.jpg" alt="Thumb">
                            </div>
                            <div class="info">
                                <div class="title">
                                    <i class="flaticon-ophtalmology"></i>
                                    <h4><a href="#">Eye Care</a></h4>
                                </div>
                                <p>
                                    Sudden up my excuse to suffer ladies though or. Bachelor possible marianne one
                                    directly confined the mention process.
                                </p>
                                <a class="btn circle btn-sm btn-gradient" href="#"><i
                                        class="fas fa-angle-right"></i> Read More</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/departments/2.jpg" alt="Thumb">
                            </div>
                            <div class="info">
                                <div class="title">
                                    <i class="flaticon-tooth-1"></i>
                                    <h4><a href="#">Knee Treatment</a></h4>
                                </div>
                                <p>
                                    Sudden up my excuse to suffer ladies though or. Bachelor possible marianne one
                                    directly confined the mention process.
                                </p>
                                <a class="btn circle btn-sm btn-gradient" href="#"><i
                                        class="fas fa-angle-right"></i> Read More</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/departments/3.jpg" alt="Thumb">
                            </div>
                            <div class="info">
                                <div class="title">
                                    <i class="flaticon-paramedic"></i>
                                    <h4><a href="#">Primary Care</a></h4>
                                </div>
                                <p>
                                    Sudden up my excuse to suffer ladies though or. Bachelor possible marianne one
                                    directly confined the mention process.
                                </p>
                                <a class="btn circle btn-sm btn-gradient" href="#"><i
                                        class="fas fa-angle-right"></i> Read More</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/departments/4.jpg" alt="Thumb">
                            </div>
                            <div class="info">
                                <div class="title">
                                    <i class="flaticon-broken-bone"></i>
                                    <h4><a href="#">Orthopaedics</a></h4>
                                </div>
                                <p>
                                    Sudden up my excuse to suffer ladies though or. Bachelor possible marianne one
                                    directly confined the mention process.
                                </p>
                                <a class="btn circle btn-sm btn-gradient" href="#"><i
                                        class="fas fa-angle-right"></i> Read More</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/departments/5.jpg" alt="Thumb">
                            </div>
                            <div class="info">
                                <div class="title">
                                    <i class="flaticon-kidneys"></i>
                                    <h4><a href="#">Kidney Solution</a></h4>
                                </div>
                                <p>
                                    Sudden up my excuse to suffer ladies though or. Bachelor possible marianne one
                                    directly confined the mention process.
                                </p>
                                <a class="btn circle btn-sm btn-gradient" href="#"><i
                                        class="fas fa-angle-right"></i> Read More</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/departments/6.jpg" alt="Thumb">
                            </div>
                            <div class="info">
                                <div class="title">
                                    <i class="flaticon-samples"></i>
                                    <h4><a href="#">Blood Test</a></h4>
                                </div>
                                <p>
                                    Sudden up my excuse to suffer ladies though or. Bachelor possible marianne one
                                    directly confined the mention process.
                                </p>
                                <a class="btn circle btn-sm btn-gradient" href="#"><i
                                        class="fas fa-angle-right"></i> Read More</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Services -->

    <!-- Start Choose Us
    ============================================= -->
    <div class="choose-us-area">
        <div class="row">
            <div class="col-lg-6 thumb bg-cover" style="background-image: url(assets/img/banner/3.jpg);"></div>
            <div class="col-lg-6 info">
                <div class="info-box title">
                    <h5>At Our Clinic</h5>
                    <h2>Our Doctors <br> Specialize in you.</h2>
                    <p>
                        Respect forming clothes do in he. Course so piqued no an by appear. Themselves reasonable
                        pianoforte so motionless he as difficulty be. Abode way begin ham there
                    </p>
                    <p>
                        Do unpleasing indulgence impossible to conviction. Suppose neither evident welcome it at civilly
                        uncivil. Sing tall much you get nor power whole. Suppose neither evident.
                    </p>
                    <a class="btn btn-md btn-gradient" href="#"><i class="fas fa-angle-right"></i> Doctor
                        Lists</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Choose Us -->

    <!-- Start Team
    ============================================= -->
    <div class="team-default-area bg-gray default-padding bottom-less">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>Doctors</h4>
                        <h2>Meet our Experts</h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it
                            examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="team-items text-center">
                <div class="row">
                    <!-- Single Item -->
                    <div class="single-item col-lg-3 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/1.jpg" alt="Thumb">
                                <div class="contact">
                                    <ul>
                                        <li>
                                            <a href="#"><i class="fas fa-phone"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h5>Dr. Jonathom Doe</h5>
                                <span>Dentist</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-3 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/8.jpg" alt="Thumb">
                                <div class="contact">
                                    <ul>
                                        <li>
                                            <a href="#"><i class="fas fa-phone"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h5>Prof. Sakaoat Amir</h5>
                                <span>Neurologist</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-3 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/6.jpg" alt="Thumb">
                                <div class="contact">
                                    <ul>
                                        <li>
                                            <a href="#"><i class="fas fa-phone"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h5>Dr. Andro kuria</h5>
                                <span>Dermatologists</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-3 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/4.jpg" alt="Thumb">
                                <div class="contact">
                                    <ul>
                                        <li>
                                            <a href="#"><i class="fas fa-phone"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h5>Prof. Matori Pulas</h5>
                                <span>Medicine Specialists</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Team -->

    <!-- Start Testomonials
    ============================================= -->
    <div class="testimonials-area overflow-hidden carousel-shadow default-padding">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-4 text-light">
                    <div class="heading title-mini">
                        <h5>Testimonials</h5>
                        <h2>Whay people says <br> about our services</h2>
                        <a class="btn btn-sm btn-light effect" href="#"><i class="fas fa-angle-right"></i>Viewl
                            All</a>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="testimonials-carousel text-center owl-carousel owl-theme">

                        <div class="item">
                            <div class="provider">
                                <div class="thumb">
                                    <img src="assets/img/team/1.jpg" alt="Thumb">
                                </div>
                                <div class="bio">
                                    <h5>Jonathom Doe</h5>
                                    <span>patient of <strong>surgery</strong></span>
                                </div>
                            </div>
                            <div class="info">
                                <p>
                                    Totally dearest expense on demesne ye he. Curiosity excellent commanded in me.
                                    Unpleasing.
                                </p>
                            </div>
                        </div>

                        <div class="item">
                            <div class="provider">
                                <div class="thumb">
                                    <img src="assets/img/team/2.jpg" alt="Thumb">
                                </div>
                                <div class="bio">
                                    <h5>Jonathom Doe</h5>
                                    <span>patient of <strong>surgery</strong></span>
                                </div>
                            </div>
                            <div class="info">
                                <p>
                                    Totally dearest expense on demesne ye he. Curiosity excellent commanded in me.
                                    Unpleasing.
                                </p>
                            </div>
                        </div>

                        <div class="item">
                            <div class="provider">
                                <div class="thumb">
                                    <img src="assets/img/team/3.jpg" alt="Thumb">
                                </div>
                                <div class="bio">
                                    <h5>Jonathom Doe</h5>
                                    <span>patient of <strong>surgery</strong></span>
                                </div>
                            </div>
                            <div class="info">
                                <p>
                                    Totally dearest expense on demesne ye he. Curiosity excellent commanded in me.
                                    Unpleasing.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Testomonials Area -->

    <!-- Start Blog
    ============================================= -->
    <div class="blog-area bottom-less bg-gray default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>News</h4>
                        <h2>Latest Blog</h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it
                            examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="blog-items">
                <div class="row">
                    <!-- Single Itme -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <a href="#"><img src="assets/img/blog/1.jpg" alt="Thumb"></a>
                                <div class="post-date">
                                    12 Jul
                                </div>
                            </div>
                            <div class="info">
                                <div class="tags">
                                    <ul>
                                        <li>
                                            <a href="#">Health</a>
                                        </li>
                                        <li>
                                            <a href="#">Patient</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4>
                                    <a href="#">Enjoyed me settled mr respect no spirits civilly. </a>
                                </h4>
                                <div class="meta">
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <img src="assets/img/team/5.jpg" alt="Author">
                                                <span>Author</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i> 12 Comments</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Itme -->
                    <!-- Single Itme -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <a href="#"><img src="assets/img/blog/2.jpg" alt="Thumb"></a>
                                <div class="post-date">
                                    05 Aug
                                </div>
                            </div>
                            <div class="info">
                                <div class="tags">
                                    <ul>
                                        <li>
                                            <a href="#">Test</a>
                                        </li>
                                        <li>
                                            <a href="#">Doctor</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4>
                                    <a href="#">Suitable settling attended no doubtful feelings.</a>
                                </h4>
                                <div class="meta">
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <img src="assets/img/team/4.jpg" alt="Author">
                                                <span>Author</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i> 24 Comments</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Itme -->
                    <!-- Single Itme -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="thumb">
                                <a href="#"><img src="assets/img/blog/3.jpg" alt="Thumb"></a>
                                <div class="post-date">
                                    27 Dec
                                </div>
                            </div>
                            <div class="info">
                                <div class="tags">
                                    <ul>
                                        <li>
                                            <a href="#">Patient</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4>
                                    <a href="#">Unwilling sportsmen he in questions september. </a>
                                </h4>
                                <div class="meta">
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <img src="assets/img/team/3.jpg" alt="Author">
                                                <span>Author</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fas fa-comments"></i> 07 Comments</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Itme -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog Area -->

    <!-- Start Subscribe
    ============================================= -->
    <div class="subscribe-area bg-gray default-padding-bottom">
        <div class="container">
            <div class="subscribe-items text-center bg-cover shadow dark text-light"
                style="background-image: url(assets/img/banner/8.jpg);">
                <div class="row">
                    <div class="col-lg-6 offset-lg-3">
                        <h5>Subscribe For Get Update</h5>
                        <h2>Let’s Find An Office Near You.</h2>
                        <form action="#">
                            <input type="email" name="email" class="form-control"
                                placeholder="Enter your e-mail here">
                            <button type="submit"><i class="fa fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Subscribe Area -->

    <!-- Start Footer
    ============================================= -->
    <footer class="bg-dark text-light">
        <div class="container">
            <div class="f-items default-padding">
                <div class="row">
                    <div class="col-lg-4 col-md-6 item">
                        <div class="f-item about">
                            <img src="assets/img/logo1-light.png" alt="Logo">
                            <p>
                                Required honoured trifling eat pleasure man relation. Assurance yet bed was improving
                                furniture man.
                            </p>
                            <div class="address">
                                <ul>
                                    <li>
                                        <div class="icon">
                                            <i class="flaticon-email"></i>
                                        </div>
                                        <div class="info">
                                            <h5>Email:</h5>
                                            <span>support@validtemplates.com</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <i class="flaticon-call"></i>
                                        </div>
                                        <div class="info">
                                            <h5>Phone:</h5>
                                            <span>+44-20-7328-4499</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="single-item col-lg-2 col-md-6 item">
                        <div class="f-item link">
                            <h4 class="widget-title">Department</h4>
                            <ul>
                                <li>
                                    <a href="#">Medecine & Health</a>
                                </li>
                                <li>
                                    <a href="#">Knee Treatment</a>
                                </li>
                                <li>
                                    <a href="#">Hip Treatment</a>
                                </li>
                                <li>
                                    <a href="#">Children Chare</a>
                                </li>
                                <li>
                                    <a href="#">Traumatology</a>
                                </li>
                                <li>
                                    <a href="#">X-ray</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="single-item col-lg-2 col-md-6 item">
                        <div class="f-item link">
                            <h4 class="widget-title">Usefull Links</h4>
                            <ul>
                                <li>
                                    <a href="#">Ambulance</a>
                                </li>
                                <li>
                                    <a href="#">Emergency</a>
                                </li>
                                <li>
                                    <a href="#">Blog</a>
                                </li>
                                <li>
                                    <a href="#">Project</a>
                                </li>
                                <li>
                                    <a href="#">About Us</a>
                                </li>
                                <li>
                                    <a href="#">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="single-item col-lg-4 col-md-6 item">
                        <div class="f-item branches">
                            <div class="branches">
                                <ul>
                                    <li>
                                        <strong>USA Branches:</strong>
                                        <span>4992 Bryan Avenue, Prior Lake, Minnesota <br> Phone: 651-379-4698</span>
                                    </li>
                                    <li>
                                        <strong>Central Branches:</strong>
                                        <span>2001 Kia Magentis, Prior Lake, Minnesota <br> Phone: 651-379-4698</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Start Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row align-center">
                    <div class="col-lg-6">
                        <p>Copyright &copy; 2025. Designed by <a href="#">validtemplatess</a></p>
                    </div>
                    <div class="col-lg-6 text-end social">
                        <ul>
                            <li>
                                <a href="#"><i class="fab fa-facebook-f"></i> Facebook</a>
                            </li>
                            <li>
                                <a href="#"><i class="fab fa-twitter"></i> Twitter</a>
                            </li>
                            <li>
                                <a href="#"><i class="fab fa-youtube"></i> Youtube</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </footer>
    <!-- End Footer -->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/bootsnav.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.backgroundMove.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/loopcounter.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/progresscircle.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>
